const fs = require('fs')
const chalk = require('chalk')



// ============ [ CONFIGURAÇÃO ] ============ \\


global.NomeDoDono = 'FaelGstz' //Preencha aqui como o primeiro campo Para o seu NOME

global.menu = 'https://telegra.ph/file/b2d75aaaed21ed7b91d49.jpg' //Preencha aqui como o primeiro campo Para a sua LOGO > FOTO DO MENU. ( OU DE ALGO QUE VC DEFINIR )

global.NomeDobot = 'DUDA-BOT-BASE' //Preencha aqui como o primeiro campo Para o nome do seu BOT

global.prefixo = '.' //Preencha aqui como o primeiro campo Para o seu prefixo ( COMANDO ANTES DO COMANDO )

global.NumeroDoDonoA = ['5516988466655'] //Preencha aqui como o primeiro campo Para o seu NUMERO ( SEM O ' + ' VALEU )


///// NÃO PRECISA MEXER AKI \\\\
global.banChats = false         /////
                                /////
global.wlcm = []                /////
                                /////
global.banChats = false         /////
///// NÃO PRECISA MEXER AKI \\\\



global.author = 'Fael' //Preencha aqui como o primeiro campo Para o seu NOME ( NOME DA FIGURINHA )

global.packname = 'DUDA-BASE' // Preencha aqui como o primeiro campo visivel a marca d'agua dos stickers. ( NOME DA FIGURINHA )

global.packname2 = 'DUDA-MULTI' // Preencha aqui como o segundo campo visivel a marca d'agua dos stickers.

global.sessionName = 'QR-DA-DUDA-BOT' // N precisa alterar isso, este campo tem funcao de alterar o nome do qr-code.

global.linkgrupss = 'https://chat.whatsapp.com/GcI1l0sflb2BMM199DmxOf' // Preencha com link do seu grupo ou deixe-o vazio.
